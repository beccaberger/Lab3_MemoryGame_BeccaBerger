//
//  ContentView.swift
//  Lab 3_Becca Berger
//
//  Created by Becca Berger on 11/5/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = DogMemoryGame()
    
    var body: some View {
        VStack {
            Text("🐶 Dog Memory Game 🐶")
                .font(.largeTitle)
                .padding()

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))]) {
                ForEach(viewModel.cards) { card in
                    DogCardView(card: card)
                        .aspectRatio(1, contentMode: .fit)
                        .onTapGesture { viewModel.choose(card) }
                }
            }
            .padding()
        }
    }
}

import SwiftUI

struct DogCardView: View {
    let card: MemoryGame<String>.Card

    var body: some View {
        ZStack {
            let shape = RoundedRectangle(cornerRadius: 10)

            if card.isFaceUp {
                shape.fill().foregroundColor(.white)
                shape.stroke(lineWidth: 3)
                Image(card.content)
                    .resizable()
                    .scaledToFit()
            } else {
                shape.fill().foregroundColor(.blue)
            }
        }
        .rotation3DEffect(.degrees(card.isFaceUp ? 0 : 180), axis: (0, 1, 0))
        .animation(.easeInOut(duration: 0.4), value: card.isFaceUp)
    }
}

