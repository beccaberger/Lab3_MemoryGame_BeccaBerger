//
//  Lab_3_Becca_BergerApp.swift
//  Lab 3_Becca Berger
//
//  Created by Becca Berger on 11/5/25.
//

import SwiftUI

@main
struct Lab_3_Becca_BergerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
